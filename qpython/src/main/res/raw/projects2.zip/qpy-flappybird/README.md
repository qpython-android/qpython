# About

QPyFlappybird is a sample game project for QPython which uses pygamesdl2 features. You should install QPython (>=2.4.0) to run it.

## How to install

Please upload this project into /sdcard/qpython/projects, then run it from QPython's start. 
